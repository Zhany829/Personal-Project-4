insert into todo(id, username,description,target_date,is_done)
values(10001, 'Zhanyu', 'Learn JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10002, 'Zhanyu', 'Learn Data JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10003, 'Zhanyu', 'Learn Microservices', sysdate(), false);